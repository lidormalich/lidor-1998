# -*- coding: utf-8 -*-

"""
    Plugin for streaming video content from seretil.me
"""
import urllib, urllib2, re, os, sys
import xbmcaddon, xbmc, xbmcplugin, xbmcgui
import urlresolver, AntiDDOSProtectcion
from z_t0mm0_common_net import Net
net2=Net()

__plugin__ = 'plugin.video.seretil'
__author__ = "Hillel"
__settings__ = xbmcaddon.Addon(id=__plugin__)
__language__ = __settings__.getLocalizedString
__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
addonPath = __settings__.getAddonInfo('path')
user_dataDir = xbmc.translatePath(__settings__.getAddonInfo("profile")).decode("utf-8")
if not os.path.exists(user_dataDir):
	os.makedirs(user_dataDir)

def unescape(text):
	try:			
		rep = {"&nbsp;": " ",
			  "\n": "",
			  "\t": "",
			  "\r":"",
			  "&#39;":"'",
			  "&quot;":"\"",
			  "&#8211;":"-",
			  "&amp;":"&",
			  "[&hellip;]":"...",
			  "&#8230;":"...",
			  "Permalink to":"",
			  "תרגום מובנה":"",
			  "לצפייה":"",
			  "ישירה":"",
			  "*":"",
			  "קישור ישיר לפוסט ":"",
			  " לצפייה ישירה":""
			  }
		for s, r in rep.items():
			text = text.replace(s, r)
			
		# remove html comments
		text = re.sub(r"<!--.+?-->", "", text)	
			
	except TypeError:
		pass

	return text

def searchInSeretil():
	search_entered =''
	keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
	keyboard.doModal()
	if keyboard.isConfirmed():
				search_entered = keyboard.getText()

	if search_entered !='' :
		INDEXSratim('http://seretil.me/?s='+search_entered.replace(' ','+'))

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
			params=sys.argv[2]
			cleanedparams=params.replace('?','')
			if (params[len(params)-1]=='/'):
					params=params[0:len(params)-2]
			pairsofparams=cleanedparams.split('&')
			param={}
			for i in range(len(pairsofparams)):
					splitparams={}
					splitparams=pairsofparams[i].split('=')
					if (len(splitparams))==2:
							param[splitparams[0]]=splitparams[1]
	return param
	
params=get_params()
url=None
iconimage=''
name=None
desc=None
mode=None
module=None
page=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        desc=urllib.unquote_plus(params["desc"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

def addLink(name,url,iconimage,desc):
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot":  desc } )
	ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
	return ok

def addDir(name,url,mode,iconimage='',desc=''):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&desc="+urllib.quote_plus(desc)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot":  desc} )
	if mode==212:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
    
def INDEXSratim(url):
	dp = xbmcgui . DialogProgress ( )
	dp.create('please wait','סבלנות')
	
	url2=url
	link=nURL(url)
	now=re.compile("<span class='pages'>עמוד (\d+) מתוך \d+<").findall(link)
	try:
	   current_page =int(str(now[0]))
	except:
		current_page=1

	stop=False

	Pages = int(__settings__.getSetting("pages"))
	while not stop:
		matches=re.compile('id="post-\d*".*?title="(.*?)">.*?<p>(.*?) href="(.*?)"', re.S).findall(link)
		for match in matches:
			url=match[2]
			name=unescape(match[0]).strip()
			desc=unescape(match[1])
			if name!="סדרות" :
				addDir(name,url,211,'',desc)
		
		if 'rel="next"' not in link:
			stop=True
		if stop:
			break
			
		current_page+=1
		url2 = url2[:-6]
		if url2[len(url2)-1]=='p' :
				url2= url2[:-1]
		elif url2[len(url2)-2]=='p' :
			   url2= url2[:-2]
			   
		url2=url2+'page/'+str(current_page)+'/'
		
		Pages = Pages - 1
		if Pages == 0:
			addDir('[COLOR blue]תוצאות נוספות[/COLOR]',url2,4,'',desc)
			stop=True
		else:
			link=nURL(url2)

def SpecialPage(url,moviename,iconimage,desc):
	link=nURL(url)
	try:
		desc = unescape(re.compile('<div class="entry(?:-content|").*?(?:<p>|<div.*?>)(.+?)<span', re.S).findall(link)[0]).replace('<span dir="rtl">', '')
	except:
		pass
	match=re.compile('>\s<span id(.*?)<iframe',re.S).findall(link)
	block=unescape(match[0]) 
	result=re.compile('a href="(.*?)"').findall(block)
	if result:
		addLink('[COLOR red]'+moviename+'[/COLOR]','',iconimage,desc)
		addLink('[COLOR red]בחר מקור לניגון, אם לא עובד נסה אחר[/COLOR]','',iconimage,desc)
		for item in result:
			try:
				final=urlresolver.HostedMediaFile(item)
				new_url=final.get_url()
				source=re.compile('http://(.*?)\/').findall(new_url)
				if final:
					addDir('[COLOR blue]'+str(source[0]) + '[/COLOR]' +  moviename +' ---- ' ,new_url,212,iconimage,desc)
			except:
				pass

def ResolverLink(url):
	url=urllib.unquote_plus(url)
	url = urlresolver.resolve(url)
	listitem = xbmcgui.ListItem(name, iconImage='', thumbnailImage='')
	url=urllib.unquote_plus(url)
	listitem.setPath(url)
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)

def CATEGORIES():
	addDir('[COLOR blue]חיפוש[/COLOR]','stam',18,'http://4.bp.blogspot.com/_ASd3nWdw8qI/TUkLNXmQwgI/AAAAAAAAAiE/XxYLicNBdqQ/s1600/Search_Feb_02_Main.png')
	addDir('סרטים ישראלים', 'http://seretil.me/category/%D7%A1%D7%A8%D7%98%D7%99%D7%9D-%D7%99%D7%A9%D7%A8%D7%90%D7%9C%D7%99%D7%9D/page/1/',4,'http://www.seret.club/wp-content/uploads/2016/03/%D7%A1%D7%A8%D7%98%D7%99%D7%9D_%D7%99%D7%A9%D7%A8%D7%90%D7%9C%D7%99%D7%9D_%D7%9C%D7%A6%D7%A4%D7%99%D7%99%D7%94_%D7%99%D7%A9%D7%99%D7%A8%D7%94-1024x576.jpg')
	addDir('סרטים מתורגמים', 'http://seretil.me/category/%D7%A1%D7%A8%D7%98%D7%99%D7%9D-%D7%9E%D7%AA%D7%95%D7%A8%D7%92%D7%9E%D7%99%D7%9D/page/1/',4,'http://www.quirindiroyaltheatre.com/wp-content/uploads/2015/11/movies-5.png')
	addDir('סרטים מדובבים', 'http://seretil.me/category/%D7%A1%D7%A8%D7%98%D7%99%D7%9D-%D7%9E%D7%93%D7%95%D7%91%D7%91%D7%99%D7%9D/page/1/',4,'http://www.in-hebrew.co.il/images/logo-s.jpg')
	addDir('סרטים ישנים', 'http://seretil.me/category/%D7%A1%D7%A8%D7%98%D7%99%D7%9D-%D7%99%D7%A9%D7%A0%D7%99%D7%9D/page/1/',4,'https://www.guthriegreen.com/sites/default/files/Back-to-the-Future.jpg')
	addDir('סרטי פעולה', 'http://seretil.me/category/%D7%A1%D7%A8%D7%98%D7%99%D7%9D/%D7%A4%D7%A2%D7%95%D7%9C%D7%94/page/1/',4,'https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcQYK9pD6O3mwT5TqYXELuSzMHxVnMCRKjxWS-CMw85Ru3dSgafX1A')
	addDir('סרטי דרמה', 'http://seretil.me/category/%D7%A1%D7%A8%D7%98%D7%99%D7%9D/%D7%93%D7%A8%D7%9E%D7%94/page/1/',4,'http://www.filmsite.org/images/drama-genre.jpg')
	addDir('סרטי אימה', 'http://seretil.me/category/%D7%A1%D7%A8%D7%98%D7%99%D7%9D/%D7%90%D7%99%D7%9E%D7%94/page/1/',4,'https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcRgtKPtptcB1sSLVy1KgnB9rXxnyAVFuhy2x7eqMBkXyfqIISIw2w')
	addDir('סרטי מדע בדיוני', 'http://seretil.me/category/%D7%A1%D7%A8%D7%98%D7%99%D7%9D/%D7%9E%D7%93%D7%A2-%D7%91%D7%93%D7%99%D7%95%D7%A0%D7%99/page/1/',4,'http://i.telegraph.co.uk/multimedia/archive/01474/et_1474485b.jpg')
	addDir('סרטי פנטזיה', 'http://seretil.me/category/%D7%A4%D7%A0%D7%98%D7%96%D7%99%D7%94/page/1/',4,'http://upload-community.kipa.co.il/blog/222203-223201311026.jpg')
	#INDEXSratim('http://seretil.me/category/%D7%A1%D7%A8%D7%98%D7%99%D7%9D-%D7%9E%D7%93%D7%95%D7%91%D7%91%D7%99%D7%9D/page1/')
	addDir('נשיונל גאוגרפיק', 'http://seretil.me/category/%D7%A0%D7%A9%D7%99%D7%95%D7%A0%D7%9C-%D7%92%D7%99%D7%90%D7%95%D7%92%D7%A8%D7%A4%D7%99%D7%A7/page/1/',4,'http://images.nationalgeographic.com/wpf/sites/common/i/presentation/NGLogo560x430-cb1343821768.png')
	addDir('אנימציה', 'http://seretil.me/category/%D7%90%D7%A0%D7%99%D7%9E%D7%A6%D7%99%D7%94/page/1/',4,'http://www.krosstalkdoubletalk.com/wp-content/uploads/2015/01/childrens_animation.jpg')
	addDir('הרפתקאות', 'http://seretil.me/category/%D7%94%D7%A8%D7%A4%D7%AA%D7%A7%D7%90%D7%95%D7%AA/page/1/',4,'http://previews.123rf.com/images/pedrolieb/pedrolieb1210/pedrolieb121000033/16084901-Clap-film-of-cinema-adventure-genre-clapperboard-text-illustration--Stock-Illustration.jpg')
	addDir('מסתורין', 'http://seretil.me/category/%D7%9E%D7%A1%D7%AA%D7%95%D7%A8%D7%99%D7%9F/page/1/',4,'http://mystery.nikawatches.ru/images/mystery.png')
	addDir('מתח', 'http://seretil.me/category/%D7%9E%D7%AA%D7%97/page/1/',4,'http://payload338.cargocollective.com/1/0/30638/9071294/thrillers-logo-black_1000.png')
	addDir('פשע', 'http://seretil.me/category/%D7%A4%D7%A9%D7%A2/page/1/',4,'http://www.mentalhealthy.co.uk/sites/default/files/bigstock_Crime_4069883.jpg')
	addDir('רומנטיקה', 'http://seretil.me/category/%D7%A8%D7%95%D7%9E%D7%A0%D7%98%D7%99%D7%A7%D7%94/page/1/',4,'http://cdn2-b.examiner.com/sites/default/files/styles/image_content_width/hash/6d/e5/6de53d85d5549b90735ea869afd0381b.JPG?itok=zD8RhwtE')
	addDir('קומדיה', 'http://seretil.me/category/%D7%A7%D7%95%D7%9E%D7%93%D7%99%D7%94/page/1/',4,'http://www.theonlinefilmfest.com/wordpress/wp-content/uploads/2014/11/toff-genre-comedy-300x231.png')
	addDir('מלחמה', 'http://seretil.me/category/%D7%9E%D7%9C%D7%97%D7%9E%D7%94/page/1/',4,'https://s3-eu-central-1.amazonaws.com/centaur-wp/creativereview/prod/content/uploads/2012/06/moma4_0.jpg')
	addDir('מוזיקלי', 'http://seretil.me/category/%D7%9E%D7%95%D7%96%D7%99%D7%A7%D7%9C%D7%99/page/1/',4,'http://previews.123rf.com/images/pedrolieb/pedrolieb1210/pedrolieb121000026/16084903-Clap-film-of-cinema-musical-genre-clapperboard-text-illustration--Stock-Illustration.jpg')
	addDir('משפחה', 'http://seretil.me/category/%D7%9E%D7%A9%D7%A4%D7%97%D7%94/page/1/',4,'http://www.truestoriesforfilm.com/wp-content/uploads/2015/06/genre-family.jpg')
	addDir('אנימה', 'http://seretil.me/category/%D7%90%D7%A0%D7%99%D7%9E%D7%94/page/1/',4,'https://media.timeout.com/images/102518979/617/347/image.jpg')
	addDir('2010', 'http://seretil.me/category/2010/page/1/',4,'http://www.freeimageslive.co.uk/image/view/1446/_original')
	addDir('2011', 'http://seretil.me/category/2011/page/1/',4,'http://www.theopen-road.com/wp-content/uploads/2012/01/2011.jpg')
	addDir('2012', 'http://seretil.me/category/2012/page/1/',4,'http://farm8.staticflickr.com/7171/6603724951_7b352bda71.jpg')
	addDir('2013', 'http://seretil.me/category/2013/page/1/',4,'http://investorplace.com/wp-content/uploads/2012/12/2013-year-630-300x227.jpg')
	addDir('2014', 'http://seretil.me/category/2014/page/1/',4,'http://mountainmessenger.com/wp-content/uploads/2014/12/sparkling_2014_lights-300x187.jpg')
	addDir('2015', 'http://seretil.me/category/2015/page/1/',4,'https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcT61KOSCwfNWb4VXqsfQTCkd-eF0R_O16FF4d4fdiyqOXhJUswB')
	addDir('2016', 'http://seretil.me/category/2016/page/1/',4,'http://api.ning.com/files/0ePsIRXUiU*tbkw-cqUlSKqpzEEiLKm1dg0YiVqdJOXql6ZFY3inVECxXl7ZHsAuIdt1D45hi8RoaxpkDgaNwniArzQUYPhp/NewYear2016.png')

def Series(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', ' Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    matches=re.compile('http://seretil.me/category/112211/(.*?)/" >(.*?)</a').findall(link)
    for match in matches:
       addDir(match[1], 'http://seretil.me/category/112211/'+str(match[0]),4,'')

def _OpenFile(path):
	if os.path.isfile(path): ## File found.
		file = open(path, 'r')
		contents=file.read()
		file.close()
		return contents
	else: return '' ## File not found.
	
def _SaveFile(path, data):
	file = open(path,'w')
	file.write(data)
	file.close()
	
def nURL(url):
	if url=='': return ''
	User_Agent='Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36'
	AntiTag='<iframe style="display:none;visibility:hidden;" src="http://my.incapsula.com/public/ga/jsTest.html" id="gaIframe"></iframe>'
	dhtml=''
	html=' '+AntiTag+' '
	net2.set_user_agent(User_Agent)
	xTimes=0
	while (AntiTag in html):
		xTimes=xTimes+1
		try: 
			html=net2.http_GET(url).content
		except urllib2.URLError,e: 
			html=dhtml
			try:
				if str(e.code)=='503':
					CFCookie=str(AntiDDOSProtectcion.decryptCFDDOSProtection(url,User_Agent,'',AddonID=__plugin__))
					cf_cookie_file=os.path.join(user_dataDir,'temp.cache.txt')
					if (str(CFCookie)=='None') or (len(str(CFCookie))==0): pass
					else:
						try: 
							my_cookies=_OpenFile(cf_cookie_file)
							if len(my_cookies)==0: my_cookies='#LWP-Cookies-2.0'
							else:
								s='\n*\r*\n*(Set-Cookie3: %s=.+? HttpOnly\s*\r*\n*\r*)'
								try:		
									cfOldA=re.compile(s%'__cfduid').findall(my_cookies)[0]
								except: cfOldA=''
								if len(cfOldA) > 0: my_cookies=my_cookies.replace(cfOldA,'')
								try:		cfOldB=re.compile(s%'cf_clearance').findall(my_cookies)[0]
								except: cfOldB=''
								if len(cfOldB) > 0: my_cookies=my_cookies.replace(cfOldB,'')
								
								gg=['\r*\n(=None; version=0\r*\n)','\r*\n(=None; version=None\r*\n)']
								for g in gg:
									try:		cfOldC=re.compile(g).findall(my_cookies)[0]
									except: cfOldC=''
									if len(cfOldC) > 0: my_cookies=my_cookies.replace(cfOldC,'')
								
								my_cookies=my_cookies.replace('\r\r\n\r\r\n','\r\r\n').replace('\n\n\r\n\n\r','\n\n\r').replace('\r\n\r\n','\r\n').replace('\n\n','\n').replace('\r\r','\r').replace('\r\a\r\a','\r\a').replace('\n\n','\n').replace('\n\a\n\a','\n\a').replace('\a\a','\a')
							_SaveFile(cf_cookie_file,my_cookies+''+str(CFCookie))

							net2.set_cookies(cf_cookie_file)
							net2.set_user_agent(User_Agent)
							html=net2.http_GET(url).content

							return html

						except: pass
				return dhtml
			except Exception, e: 
				print e
				return dhtml
				pass
		except Exception, e: 
			html=dhtml
		except: 
			html=dhtml
		if xTimes > 5: 
			html=html.replace(AntiTag,'')
		elif AntiTag in html: 
			xbmc.sleep(4000)

	return html
		

if mode==None or url==None or len(url)<1:
	CATEGORIES()
elif mode==4:
	INDEXSratim(url)
elif mode==8:
	Series(url)
elif mode==18:
	searchInSeretil()
elif mode==211:
	SpecialPage(url,name,iconimage,desc)
elif mode==212:
	ResolverLink(url)

xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
xbmc.executebuiltin("Container.SetViewMode(504)")

xbmcplugin.endOfDirectory(int(sys.argv[1]),cacheToDisc=True)
