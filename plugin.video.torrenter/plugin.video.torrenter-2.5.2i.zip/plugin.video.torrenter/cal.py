# -*- coding: utf-8 -*-
encoding = None or 'utf-8'
print encoding