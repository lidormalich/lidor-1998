# -*- coding: utf-8 -*-
import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os

from variables import *
from shared_modules import *
if "plugin." in addonID: from shared_modules3 import *

#from modulesZ import *
#from modulesA import *
'''---------------------------'''
	
def CATEGORIES():
	'''------------------------------
	---MAIN--------------------------
	------------------------------'''
	try: General_Language = getsetting('General_Language')
	except: General_Language = systemlanguage
	
	
	addDir("הדרכה",'',100,"",'','1',58, getAddonFanart(101, default="", urlcheck_=True)) #פספוסים
'''
	פליליסט מלא PLuH2hTdpWoUiB6O7fl3YEOPRk-jigsTOi
	'''

	

def CATEGORIES100(name, iconimage, desc, fanart):#הרחבות
	background = 100
	background2 = fanart
	#
	fanart = '' #גדול
	thumb = '' #בינוני'''
	list = []
	
	list.append('&youtube_pl=PLuH2hTdpWoUiY588vha5bvp-Fhsc_5tAX')
	addDir("מדריכי הרחבות",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_pl=PLuH2hTdpWoUiY588vha5bvp-Fhsc_5tAX',58, getAddonFanart(background, default='getAPIdata', custom=""))
	#
	fanart = '' #גדול
	thumb = '' #בינוני'''
	list = []
	
	list.append('&youtube_pl=PLuH2hTdpWoUjWb_7kTFaBssA3QPKWq9Ki')
	addDir("טלוויזיה חיה-צפיה ישירה",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_pl=PLuH2hTdpWoUjWb_7kTFaBssA3QPKWq9Ki',58, getAddonFanart(background, default='getAPIdata', custom=""))
	#
	fanart = '' #גדול
	thumb = '' #בינוני'''
	list = []
	
	list.append('&youtube_pl=PLuH2hTdpWoUiSTS4OmyJ5N_q6IS0ZZCxt')
	addDir("בניית קיר סרטים-סדרות או מוזיקה",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_pl=PLuH2hTdpWoUjFmWChDGZPQTWBWdmqzx7y',58, getAddonFanart(background, default='getAPIdata', custom=""))
	#
	fanart = '' #גדול
	thumb = '' #בינוני'''
	list = []
	
	list.append('&youtube_pl=PLuH2hTdpWoUgv4C42CsdtxMHT65KaMObZ')
	addDir("התקנת וויזארד לקודי",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_pl=PLuH2hTdpWoUgv4C42CsdtxMHT65KaMObZ',58, getAddonFanart(background, default='getAPIdata', custom=""))
	
	#
	fanart = '' #גדול
	thumb = '' #בינוני'''
	list = []
	
	list.append('&youtube_pl=PLuH2hTdpWoUh9ERQn-pxVAtpV_oHyYuJE')
	addDir("שידרוג צפיה ומחיקת קודי",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_pl=PLuH2hTdpWoUh9ERQn-pxVAtpV_oHyYuJE',58, getAddonFanart(background, default='getAPIdata', custom=""))
	#
	fanart = '' #גדול
	thumb = '' #בינוני'''
	list = []
	
	list.append('&youtube_pl=PLuH2hTdpWoUiB6O7fl3YEOPRk-jigsTOi')
	addDir("הפליליסט המלא",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_pl=PLuH2hTdpWoUiB6O7fl3YEOPRk-jigsTOi',58, getAddonFanart(background, default='getAPIdata', custom=""))
	
	
'''
PLuH2hTdpWoUgv4C42CsdtxMHT65KaMObZ		וויזארדים לקודי-ישראלי
PLuH2hTdpWoUjFmWChDGZPQTWBWdmqzx7y		בניית וויזארדים
PLuH2hTdpWoUjWb_7kTFaBssA3QPKWq9Ki		טלוויזיה חיה
PLuH2hTdpWoUh9ERQn-pxVAtpV_oHyYuJE		שדרוג מהירות ופעולה של קודי
PLuH2hTdpWoUiY588vha5bvp-Fhsc_5tAX		הרחבות
PLuH2hTdpWoUiSTS4OmyJ5N_q6IS0ZZCxt		קירות






'''
	
	
	