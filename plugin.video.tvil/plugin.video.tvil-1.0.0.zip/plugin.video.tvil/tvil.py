# -*- coding: utf-8 -*-
import requests,re
from bs4 import BeautifulSoup
 
def GetSeries(url):
     
    r = requests.get(url)
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    
    Source =  soup.findAll('div', {"id": "page-right"})
    showsList = []
    for scripts in Source:
        div =  soup.findAll('div', {"class": "compact-progress-div"})
        for script in div:
            title =  script.find('div').text
            image = script.find('img').get('src')
            url = 'http://www.tvil.me/?page=view&id='+script.get('id').replace('link-','')+'&mode=v'
            showsList.append({'title':title,'url':url,'image':image})
    return showsList

def GetSeason(url):
 
    r = requests.get(url)
    soup = BeautifulSoup(r.text, 'html5lib')

    Source =  soup.find('div', {"id": "view-seasons-show"}).findAll('div')
    seasonList = []
    for link in Source:
        title = u'עונה ' + link.a.text
        url = link.a.get('href')
        seasonList.append({'title':title,'url':url})
    return seasonList
    
def GetEpisodes(url):
    
    r = requests.get(url)
    soup = BeautifulSoup(r.text, 'html5lib')
    Source =  soup.find('div', {"id": "view-episodes-show"}).findAll('div')
    episodesList = []
    for link in Source:
        title = u'פרק ' + link.a.text
        url = link.a.get('href')
        episodesList.append({'title':title,'url':url})
    return episodesList

def GetSearch(query):
    r = requests.get('http://www.tvil.me/ajax.php?module=search&input='+query.replace(' ','+'))
    r.encoding = 'utf-8'
    soup = BeautifulSoup(r.text, 'html5lib')
    results = soup.findAll('div',{'class':'search-result'})
    
    resultsList = []
    for result in results:
        if result.find('a') != None:
            resultsList.append({'title':result.find('a').text,'url':result.find('a').get('href'),'thumbnail':result.find('img').get('src')})
        
    return resultsList

def GetStreams(url):
    
    r = requests.get(url)
    soup = BeautifulSoup(r.text, 'html5lib')
    soup.prettify()
    divs =  soup.findAll('div', {"class": "view-watch-button"})
    divs += soup.findAll('div',{'class':'view-download-button'})
    streamsList = []
    for link in divs:
        title = link.find('a').text
        url = link.find('a').get('href').replace('\n','')
        streamsList.append({'title':title,'url':url})
    return streamsList
    
def upf(url):
    s = requests.Session()
    s.headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36'}
    r=s.get(url)
    preview = re.compile('window.open\\("(.*)","_blank"').findall(r.text)[0]
    r=s.get(preview)
    return re.compile("video src='(.*)' controls").findall(r.text)[0]

def wholecloud(url):
    url = url.replace('video/','embed/?v=')
    s = requests.Session()
    s.headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.106 Safari/537.36'}
    r=s.get(url)
    key = re.compile('var fkzd="(.*)";').findall(r.text)[0]
    file = re.compile('flashvars.file="(.*)";').findall(r.text)[0]
    api_url = 'http://www.wholecloud.net/api/player.api.php?key='+key+'&numOfErrors=0&user=undefined&cid=0&file='+file
    r=s.get(api_url)
    return re.compile('url=(.*).flv').findall(r.text)[0]+'.flv'
#GetStreams()
