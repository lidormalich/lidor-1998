# -*- coding: utf-8 -*-

########ToMeR For Addons Premium##########


import urllib,urllib2,re,xbmcplugin,xbmcgui,os,sys,datetime
from resources.lib.common_variables import *
from resources.lib.directory import *
from resources.lib.youtubewrapper import *
from resources.lib.watched import * 

fanart = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.ani10', 'fanart.jpg'))
art = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.ani10/resources/img', ''))

def CATEGORIES():
        addDir('כיתה א','url',11,art + '92.jpg')
        addDir('כיתה ב','url',12,art + '93.jpg')
        addDir('כיתה ג','url',13,art + '94.jpg')
        addDir('כיתה ד','url',14,art + '95.jpg')
        addDir('כיתה ה','url',15,art + '96.jpg')
        addDir('כיתה ו','url',16,art + '97.jpg')
        addDir('כיתה ז','url',17,art + '98.jpg')
        addDir('כיתה ח','url',18,art + '99.jpg')
        addDir('כיתה ט','url',19,art + '100.jpg')
        addDir('כיתה י','url',20,art + '101.jpg')
        addDir('כיתה יא','url',21,art + '102.jpg')
        addDir('כיתה יב','url',22,art + '103.jpg')
		
		
def kitaalf():	
		addDir('חשבון - שיעורים'+translate(30059)+'','PLU33OzuSK_IFfEp_vzBCEc6oIR1udhGUH',1,art + '1.jpg')	
		addDir('חשבון - פתרון מבחנים'+translate(30059)+'','PLU33OzuSK_IFhWdHKdlgfeE3H9nFLK4vK',1,art + '2.jpg')	
		addDir('גיאומטריה - שיעורים'+translate(30059)+'','PLU33OzuSK_IFPSy2AqYI5jhxGKkZ0dZ1Z',1,art + '3.jpg')
		addDir('גיאומטריה - פתרון מבחנים'+translate(30059)+'','PLU33OzuSK_IHR2MZl3plYp7I_C4qPgnLB',1,art + '4.jpg')	
		
def kitabit():	
		addDir('חשבון - שיעורים'+translate(30059)+'','PLUhMn67YK8oLSa3OoHh74UUWhyTEmTyT7',1,art + '5.jpg')	
		addDir('חשבון - פתרון מבחנים'+translate(30059)+'','PLUhMn67YK8oJx3hk1BcmK0YiQ5ijRe4jt',1,art + '6.jpg')	
		addDir('גיאומטריה - שיעורים'+translate(30059)+'','PLUhMn67YK8oI42XTMHW2fFsxxzowe7BS3',1,art + '7.jpg')
		addDir('גיאומטריה - פתרון מבחנים'+translate(30059)+'','PLUhMn67YK8oLjBpaB7O5cMY5teF-aJGdP',1,art + '8.jpg')

def kitagimal():	
		addDir('חשבון - שיעורים'+translate(30059)+'','PLUhMn67YK8oKzUlpjmW-10YX5LXrNDLYC',1,art + '9.jpg')	
		addDir('חשבון - פתרון מבחנים'+translate(30059)+'','PLUhMn67YK8oL5DyXVhmp1LHYG8whJjRxK',1,art + '10.jpg')	
		addDir('גיאומטריה - שיעורים'+translate(30059)+'','PLUhMn67YK8oJrFToQITdAcunVnMbMlcFF',1,art + '11.jpg')
		addDir('גיאומטריה - פתרון מבחנים'+translate(30059)+'','PLUhMn67YK8oJfw908vHPejevdhj6-6_lh',1,art + '12.jpg')

def kitadald():	
		addDir('חשבון - שיעורים'+translate(30059)+'','PLUhMn67YK8oJJyfOmwZcgECXeN7RuOw9F',1,art + '13.jpg')	
		addDir('חשבון - פתרון מבחנים'+translate(30059)+'','PLUhMn67YK8oK7oqezd-yz6kUR_qNe9UoO',1,art + '14.jpg')	
		addDir('גיאומטריה - שיעורים'+translate(30059)+'','PLUhMn67YK8oKLV6IYHc40wt8I1O-EJvH3',1,art + '15.jpg')
		addDir('גיאומטריה - פתרון מבחנים'+translate(30059)+'','PLUhMn67YK8oIQlUqt_EGTv0PxFUbFUP-j',1,art + '16.jpg')

def kitahii():
		addDir('חשבון - שיעורים'+translate(30059)+'','PLUhMn67YK8oJe91Gfqbw21fAbfM6Gfppx',1,art + '17.jpg')	
		addDir('חשבון – פתרון מבחן מיצ"ב תשס"ט + תש"ע'+translate(30059)+'','PLUhMn67YK8oJuWo5x9Gdu9rxTV8z2GZrX',1,art + '18.jpg')	
		addDir('חשבון – פתרון מבחן מיצ"ב תשע"ג + תשע"ד'+translate(30059)+'','PLUhMn67YK8oKbE1SRzKcQ2ooSE9P0Kjed',1,art + '19.jpg')
		addDir('חשבון – פתרון מבחן מיצ"ב תשע"ה'+translate(30059)+'','PLUhMn67YK8oKN2yb2Jf16PPTW97M3kw2t',1,art + '20.jpg')
		addDir('גיאומטריה – שיעורים'+translate(30059)+'','PLUhMn67YK8oKp7aIgsoVt3XwR3ZUR74cZ',1,art + '21.jpg')		
		addDir('גיאומטריה – פתרון מבחן מסכם'+translate(30059)+'','PLUhMn67YK8oI_GNqX_aoaPBc4tqpsXNhf',1,art + '22.jpg')
		addDir('גיאומטריה – פתרון מבחן מיצ"ב תשע"ג + תשע"ד'+translate(30059)+'','PLUhMn67YK8oLNQSD1yc9wSyH_8UZ7L2gu',1,art + '23.jpg')
		addDir('גיאומטריה – פתרון מבחן מיצ"ב תשע"ה'+translate(30059)+'','PLUhMn67YK8oK2HEZ5KWVotjWQbsoDVd0_',1,art + '24.jpg')
		
def kitavev():
		addDir('חשבון - שיעורים'+translate(30059)+'','PLUhMn67YK8oKUZi-WqnMPBowlDfMk-OT7',1,art + '25.jpg')	
		addDir('חשבון - פתרון מבחנים'+translate(30059)+'','PLUhMn67YK8oK_GJapfyzFGp_hyIgpn0hY',1,art + '26.jpg')	
		addDir('גיאומטריה - שיעורים'+translate(30059)+'','PLUhMn67YK8oK3tXe0Pj1HmwrBwGAa3Jpg',1,art + '27.jpg')
		addDir('גיאומטריה - פתרון מבחנים'+translate(30059)+'','PLUhMn67YK8oKNymsFcpNc1J0I_HMfyiu3',1,art + '28.jpg')

def kitazin():
		addDir('אלגברה – שיעורים'+translate(30059)+'','PLUhMn67YK8oIdnjKGsT3Hv2zk5qLJcITZ',1,art + '29.jpg')	
		addDir('אלגברה – פתרון מפמ"ר תשס"ח'+translate(30059)+'','PLUhMn67YK8oIIcopLKWwJGo6Yq_kQlTwA',1,art + '30.jpg')	
		addDir('אלגברה – פתרון מפמ"ר תש"ע'+translate(30059)+'','PLUhMn67YK8oIMt1_nMsuhCeEzCyh_igjv',1,art + '31.jpg')
		addDir('אלגברה – פתרון מפמ"ר תשע"ב'+translate(30059)+'','PLUhMn67YK8oK9d81bTGJf0zbAXNUGiG54',1,art + '32.jpg')
		addDir('גיאומטריה – שיעורים'+translate(30059)+'','PLUhMn67YK8oLEZr59Y9WmGnJBoMxGlyBW',1,art + '33.jpg')
		addDir('גיאומטריה – פתרון מבחני מפמ"ר'+translate(30059)+'','PLUhMn67YK8oIM3zJRt0kfFG-GX11YJ2mv',1,art + '34.jpg')
		addDir('גיאומטריה – פתרון מפמ"ר תשע"ב'+translate(30059)+'','PLUhMn67YK8oLPPgoFwEKn1KY39_n3KNH2',1,art + '35.jpg')

def kitahet():
		addDir('אלגברה – שיעורים'+translate(30059)+'','PLUhMn67YK8oISaEUj4OY0F79CiI-WIhts',1,art + '36.jpg')	
		addDir('אלגברה – פתרון מיצ"ב תשע"ב נוסח א + נוסח ב'+translate(30059)+'','PLUhMn67YK8oIamJTxcVGobZX1r86OZMfu',1,art + '37.jpg')	
		addDir('אלגברה – פתרון מיצ"ב תשע"ג + תשע"ד'+translate(30059)+'','PLUhMn67YK8oKTjg7ZpQblSWKcRvcHiekq',1,art + '38.jpg')
		addDir('אלגברה – פתרון מיצ"ב תשע"ה'+translate(30059)+'','PLUhMn67YK8oJhTk_P1JvdddvCehGGvIIX',1,art + '39.jpg')
		addDir('גיאומטריה – שיעורים'+translate(30059)+'','PLUhMn67YK8oLUGzcYKQ8gJcOO3vJPlS_p',1,art + '40.jpg')
		addDir('גיאומטריה – פתרון מיצ"ב תשע"ב נוסח א + נוסח ב'+translate(30059)+'','PLUhMn67YK8oK4cX4ooTcCjOlXiBG6TzZw',1,art + '41.jpg')

def kitatat():
		addDir('אלגברה – שיעורים'+translate(30059)+'','PLUhMn67YK8oL3KhWD-H06kNMZp0U9JPJx',1,art + '42.jpg')	
		addDir('אלגברה – פתרון מבחן מפמ"ר תש"ע + תשע"א'+translate(30059)+'','PLUhMn67YK8oKDgAlN3bSFR_aIRdJW_Eaz',1,art + '43.jpg')	
		addDir('אלגברה – פתרון מפמ"ר תשע"ב + תשע"ג'+translate(30059)+'','PLUhMn67YK8oL5R6idyiLQoDuWH7-xtoFu',1,art + '44.jpg')
		addDir('אלגברה – פתרון מפמ"ר תשע"ד'+translate(30059)+'','PLUhMn67YK8oKdmDPm2rqxIdLU2Mt3XwXe',1,art + '45.jpg')
		addDir('גיאומטריה – שיעורים'+translate(30059)+'','PLUhMn67YK8oKIOQXd7wPeW-AZquEQnQP7',1,art + '46.jpg')
		addDir('גיאומטריה – פתרון מפמ"ר תש"ע + תשע"א'+translate(30059)+'','PLUhMn67YK8oIHOLYTNOzBTvtyA-gYDLRV',1,art + '47.jpg')
		addDir('גיאומטריה – פתרון מפמ"ר תשע"ב + תשע"ג'+translate(30059)+'','PLUhMn67YK8oI93Rkb85Jpbaf6Lp5JlC_0',1,art + '48.jpg')
		addDir('גיאומטריה – פתרון מפמ"ר תשע"ד'+translate(30059)+'','PLUhMn67YK8oJD-XrAMhm6Djr8iFSYwLNq',1,art + '49.jpg')

def kitayod():
		addDir('801 – 3 יחידות – שיעורי אלגברה'+translate(30059)+'','PLUhMn67YK8oKVBVXVn8czG8XN1fpxtGO2',1,art + '50.jpg')	
		addDir('801 – 3 יחידות – טריגונומטריה'+translate(30059)+'','PLUhMn67YK8oKX1aKefMcSfZi3ybM6Xjls',1,art + '51.jpg')	
		addDir('801 – 3 יחידות – גיאומטריה אנליטית'+translate(30059)+'','PLUhMn67YK8oKVwssrP9nA383uI55im9ta',1,art + '52.jpg')
		addDir('801 – 3 יחידות – פתרון בגרות חורף תשע"ג + קיץ תשע"ג'+translate(30059)+'','PLUhMn67YK8oISE8kCHrmp9KpXTrimG9tG',1,art + '53.jpg')
		addDir('801 – 3 יחידות – פתרון בגרות חורף תשע"ד + קיץ תשע"ד'+translate(30059)+'','PLUhMn67YK8oLgWl0llFKV9Q7UL013BxeX',1,art + '54.jpg')
		addDir('801 – 3 יחידות – פתרון בגרות חורף תשע"ה'+translate(30059)+'','PLUhMn67YK8oIe6qg6yXy3Pvc6sMC3XxnB',1,art + '55.jpg')
		addDir('804 – 4 יחידות – אלגברה'+translate(30059)+'','PLUhMn67YK8oKVlzwQZzo5DZR93oHABP5w',1,art + '56.jpg')
		addDir('804 – 4 יחידות – גיאומטריה'+translate(30059)+'','PLUhMn67YK8oJPnOXVkm6VZkDaSET6Dqv3',1,art + '57.jpg')
		addDir('804 – 4 יחידות – גיאומטריה אנליטית'+translate(30059)+'','PLUhMn67YK8oKug8Qhh8sL2KewdMma2D-O',1,art + '58.jpg')
		addDir('804 – 4 יחידות – טריגונומטריה'+translate(30059)+'','PLUhMn67YK8oKFygEh0JaK1kI0_ouMph1i',1,art + '59.jpg')
		addDir('806 – 5 יחידות – אלגברה'+translate(30059)+'','PLUhMn67YK8oK0KBGuaLCTJg04mSBtrZ0V',1,art + '60.jpg')

def kitayoda():
		addDir('802 – 3 יחידות – אלגברה'+translate(30059)+'','PLUhMn67YK8oLQyy2y324SwsYmgvOe_XeZ',1,art + '61.jpg')	
		addDir('802 – 3 יחידות – הנדסת המרחב'+translate(30059)+'','PLUhMn67YK8oK-HJsNUjasitNQQ8oTRljw',1,art + '62.jpg')	
		addDir('802 – 3 יחידות – פתרון בגרות חורף תשע"ג + קיץ תשע"ג'+translate(30059)+'','PLUhMn67YK8oIUEBy6d70hJsnPkycLERgq',1,art + '63.jpg')
		addDir('802 – 3 יחידות – פתרון בגרות חורף תשע"ד + קיץ תשע"ד'+translate(30059)+'','PLUhMn67YK8oKvBZ9lpuKK7TdWYr6xWgiR',1,art + '64.jpg')
		addDir('802 – 3 יחידות – פתרון בגרות חורף תשע"ה'+translate(30059)+'','PLUhMn67YK8oIHMhOhkeMVxGD4c3cGwgfo',1,art + '65.jpg')
		addDir('804 – 4 יחידות – גאומטריה אנליטית'+translate(30059)+'','PLUhMn67YK8oIqjdtyM7XsHun4Wf-C_80w',1,art + '66.jpg')
		addDir('804 – 4 יחידות – אלגברה'+translate(30059)+'','PLUhMn67YK8oINociWEtabtMDwZ__qNmZ0',1,art + '67.jpg')
		addDir('804 – 4 יחידות – חשבון דיפרנציאלי ואינטגרלי'+translate(30059)+'','PLUhMn67YK8oLb7S7BdFHq_aAzBwIXLYsk',1,art + '68.jpg')
		addDir('804 – 4 יחידות – הסתברות'+translate(30059)+'','PLUhMn67YK8oI0AnDZ0NFQWc8WsbGqvCYp',1,art + '69.jpg')
		addDir('804 – 4 יחידות – טריגונומטריה'+translate(30059)+'','PLUhMn67YK8oLF1c8oyqRjTYXxl6NkiUaT',1,art + '70.jpg')
		addDir('804 – 4 יחידות – פתרון בגרות קיץ תשע"ד'+translate(30059)+'','PLUhMn67YK8oLFxkw78TGv1dDkBQlOSB4-',1,art + '71.jpg')
		addDir('806 – 5 יחידות – טריגונומטריה'+translate(30059)+'','PLUhMn67YK8oLubiRI20gMvdrYGQI0x5QU',1,art + '72.jpg')
		addDir('806 – 5 יחידות – גיאומטריה'+translate(30059)+'','PLUhMn67YK8oKhS4Mq6D8xwhrMk0XDF2Ym',1,art + '73.jpg')
		addDir('806 – 5 יחידות – בגרות קיץ תשע"ג'+translate(30059)+'','PLUhMn67YK8oLCfpPUEL7BF0mskfkzDg0c',1,art + '74.jpg')

def kitayodb():
		addDir('803 – 3 יחידות – אלגברה'+translate(30059)+'','PLUhMn67YK8oJeQVSCdW4MNhCelyNrCm4Z',1,art + '75.jpg')	
		addDir('803 – 3 יחידות – גיאומטריה אנליטית'+translate(30059)+'','PLUhMn67YK8oKg1tHjHvA8ITw1H2VZR_qJ',1,art + '76.jpg')	
		addDir('803 – 3 יחידות – חשבון דיפרנציאלי ואינטגרלי'+translate(30059)+'','PLUhMn67YK8oKFOGqYJ4QzJpjWtLizlM2S',1,art + '77.jpg')
		addDir('803 – 3 יחידות – פתרון בגרות חורף תשע"ג + קיץ תשע"ג'+translate(30059)+'','PLUhMn67YK8oKRdpXnewrV6bIvUkzdW179',1,art + '78.jpg')
		addDir('803 – 3 יחידות – פתרון בגרות חורף תשע"ד + קיץ תשע"ד'+translate(30059)+'','PLUhMn67YK8oJ0w_cIhYU0uhBFYGII1OuA',1,art + '79.jpg')
		addDir('803 – 3 יחידות – פתרון בגרות חורף תשע"ה'+translate(30059)+'','PLUhMn67YK8oK4kmDQGWP4zAFDvR4fWjwq',1,art + '80.jpg')
		addDir('805 – 4 יחידות – אלגברה מבוא'+translate(30059)+'','PLUhMn67YK8oJXvbUwWoTgT3B0wxnXp5LW',1,art + '81.jpg')
		addDir('805 – 4 יחידות – אלגברה סדרות'+translate(30059)+'','PLUhMn67YK8oL2lTLjpByGSB3JXI_8pTcx',1,art + '82.jpg')
		addDir('805 – 4 יחידות – חשבון דיפרנציאלי ואינטגרלי'+translate(30059)+'','PLUhMn67YK8oIT9i1v2S-lA0H1NVeD2Nim',1,art + '83.jpg')
		addDir('805 – 4 יחידות – טריגונומטריה במרחב'+translate(30059)+'','PLUhMn67YK8oKuoc6nhG6X8gxDCkVwxfaq',1,art + '84.jpg')
		addDir('805 – 4 יחידות – פתרון בגרות קיץ תשע"ד'+translate(30059)+'','PLUhMn67YK8oJpJV5Mo7qeQ1PDRpcHoCqt-',1,art + '85.jpg')
		addDir('807 – 5 יחידות – אלגברה'+translate(30059)+'','PLUhMn67YK8oLoTrEh0wS3-no6Uxlw1fYx',1,art + '86.jpg')
		addDir('807 – וקטורים'+translate(30059)+'','PLUhMn67YK8oLaeURU0Tn9rTSZaGhA0Duc',1,art + '87.jpg')
		addDir('807 – מספרים מרוכבים'+translate(30059)+'','PLUhMn67YK8oK3qugb-Zw6wSfYWzcDiRyX',1,art + '88.jpg')
		addDir('807 – 5 יחידות – גאומטריה'+translate(30059)+'','PLUhMn67YK8oIM-2GBeaYR0am9qQ9NQS-k',1,art + '89.jpg')
		addDir('807 – 5 יחידות – פתרון בגרות קיץ תשע"ד'+translate(30059)+'','PLUhMn67YK8oK2nBBj6twl6FyyVJPUX9Xl',1,art + '90.jpg')
		addDir('807 – 5 יחידות – פתרון בגרות חורף תשע"ו'+translate(30059)+'','PLUhMn67YK8oIuyKbfhlmzWjcV4_x4TiFX',1,art + '91.jpg')

def ani10(url):
		
    ok=True        
    xbmc.executebuiltin('XBMC.Container.Update(%s)' % url )
    return ok
        
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param


params=get_params()
url=None
name=None
mode=None
iconimage=None
page = None
token = None

try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except:
	try: 
		mode=params["mode"]
	except: pass
try: iconimage=urllib.unquote_plus(params["iconimage"])
except: pass
try: token=urllib.unquote_plus(params["token"])
except: pass
try: page=int(params["page"])
except: page = 1

print ("Mode: "+str(mode))
print ("URL: "+str(url))
print ("Name: "+str(name))
print ("iconimage: "+str(iconimage))
print ("Page: "+str(page))
print ("Token: "+str(token))

		
def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="NEXT.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
def addDir3(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setProperty('fanart_image', fanart)
        if mode==35 :
               ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
               return ok
				
def create_directory(dir_path, dir_name=None):
    if dir_name:
        dir_path = os.path.join(dir_path, dir_name)
    dir_path = dir_path.strip()
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
    return dir_path

if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
       
elif mode==1:
        return_youtubevideos(name,url,token,page)

elif mode==5: 
        play_youtube_video(url)

elif mode==6:
        mark_as_watched(url)

elif mode==7:
        removed_watched(url)

elif mode==8:
        add_to_bookmarks(url)

elif mode==9:
        remove_from_bookmarks(url)
		
elif mode==11:
        print ""+url
        kitaalf()

elif mode==12:
        print ""+url
        kitabit()
		
elif mode==13:
        print ""+url
        kitagimal()	
		
elif mode==14:
        print ""+url
        kitadald()
		
elif mode==15:
        print ""+url
        kitahii()	
	
elif mode==16:
        print ""+url
        kitavev()	

elif mode==17:
        print ""+url
        kitazin()

elif mode==18:
        print ""+url
        kitahet()
		
elif mode==19:
        print ""+url
        kitatat()	
		
elif mode==20:
        print ""+url
        kitayod()
		
elif mode==21:
        print ""+url
        kitayoda()	
	
elif mode==22:
        print ""+url
        kitayodb()
		
xbmcplugin.endOfDirectory(int(sys.argv[1]))