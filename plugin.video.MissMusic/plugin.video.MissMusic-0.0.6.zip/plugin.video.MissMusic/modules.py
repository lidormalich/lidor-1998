# -*- coding: utf-8 -*-
import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os

from variables import *
from shared_modules import *
if "plugin." in addonID: from shared_modules3 import *

from modulesZ import *
from modulesA import *
'''---------------------------'''
	
def CATEGORIES():
	'''------------------------------
	---MAIN--------------------------
	------------------------------'''
	try: General_Language = getsetting('General_Language')
	except: General_Language = systemlanguage
	
	CATEGORIES_SEARCH(mode=30, url="")
	
	addDir("שרית חדד",'',101,'http://haflla.com/wp-content/uploads/2015/01/pic15.jpg','','1',58, getAddonFanart(101, default="http://www.pichevkes.co.il/wp-content/uploads/2016/02/12764844_1020167398005700_6669465870314847083_o.jpg", urlcheck_=True)) #פספוסים
	addDir("שירי מימון",'',102,'http://www.guitarfree.co.il/wp-content/uploads/095ff5564d7de7da54ca77d6af8bfcdc.jpg','','1',58, getAddonFanart(102, default="http://blinker.co.il/wp-content/uploads/2012/07/PANDORA-%D7%A9%D7%99%D7%A8%D7%99-%D7%9E%D7%99%D7%99%D7%9E%D7%95%D7%9F.-%D7%A6%D7%9C%D7%9D-%D7%90%D7%9C%D7%95%D7%9F-%D7%A9%D7%A4%D7%A8%D7%A0%D7%A1%D7%A7%D7%99.jpg", urlcheck_=True)) #תוכניות ישראליות
	addDir("קרן פלס",'',103,'http://i.imgur.com/j3QO1wn.jpg','','1',2, getAddonFanart(103, default="http://forumsgallery.tapuz.co.il/ForumsGallery/galleryimages/321048383.jpg", urlcheck_=True)) #סטנדאפ ישראלי
	


def CATEGORIES101(name, iconimage, desc, fanart):
	'''שרית חדד'''
	background = 101
	background2 = fanart
	
	
	
	list = []
	
	list.append('&youtube_ch=SaritHadadOfficial')
	addDir("האזנה ישירה לשרית חדד",list,17,thumb,addonString(1).encode('utf-8'),'1',"",getAddonFanart(background, custom=fanart, default=background2))
def CATEGORIES102(name, iconimage, desc, fanart):
	background = 102
	background2 = fanart
	'''שירי מימון'''

	list = []
	list.append('&youtube_ch=ShiriMaimonOfficial')
	addDir("האזנה ישירה לשירי מימון",list,17,thumb,addonString(2).encode('utf-8'),'1',"",getAddonFanart(background, custom=fanart, default=background2))
		
def CATEGORIES103(name, iconimage, desc, fanart):
	'''קרן פלס'''
	
	background = 103
	background2 = fanart
	commonsearch = 'commonsearch103'
	
	CATEGORIES_RANDOM(background,fanart) #אקראי
	fanart = 'http://megafon-news.co.il/asys/wp-content/uploads/2013/10/%D7%94%D7%97%D7%99%D7%99%D7%9C-%D7%94%D7%90%D7%9E%D7%99%D7%A5-%D7%A9%D7%95%D7%95%D7%99%D7%A7-%D7%90%D7%91%D7%99-%D7%A7%D7%95%D7%A9%D7%A0%D7%99%D7%A8-%D7%A6%D7%99%D7%9C%D7%95%D7%9D-%D7%96%D7%A8%D7%90%D7%A8-%D7%90%D7%9C%D7%95%D7%9F.jpg' #גדול
	thumb = 'http://moridim.me/images/large/1745.jpg' #בינוני
	list = []
	
	list.append('&youtube_ch=KerenPelesOfficial')
	addDir("האזנה ישירה לקרן פלס",list,17,thumb,addonString(3).encode('utf-8'),'1',"",getAddonFanart(background, custom=fanart, default=background2))
