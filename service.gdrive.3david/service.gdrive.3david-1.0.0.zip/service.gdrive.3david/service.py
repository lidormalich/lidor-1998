#!/usr/bin/python
import os, xbmcaddon,shutil, glob

def copytree(source, target):
	files = glob.glob(os.path.join(source,"*"))

	for f in files:
		shutil.copyfile(f,os.path.join(target, os.path.basename(f)))

addonID = "service.gdrive.3david"
Addon = xbmcaddon.Addon(addonID)
AddonName = Addon.getAddonInfo("name")
AddonVer = Addon.getAddonInfo("version")

source = xbmc.translatePath(os.path.join('special://home','addons',addonID,'resources')); 
target = xbmc.translatePath(os.path.join('special://userdata','addon_data','plugin.video.gdrive')); 
lastUpdateFile = os.path.join(target, AddonVer+'.txt')

if not os.path.isfile(lastUpdateFile):
	if not os.path.exists(target):
		os.makedirs(target)
	# Copy new files
	copytree(source, target)

	f = open(lastUpdateFile, 'w')
	f.write(".")
	f.close()